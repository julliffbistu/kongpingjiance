 #include <iostream>
 2 #include <windows.h>
 3 using namespace std;
 4 
 5 HANDLE hMutex = NULL;//互斥量
 6 //线程函数
 7 DWORD WINAPI Fun(LPVOID lpParamter)
 8 {
 9     for (int i = 0; i < 10; i++)
10     {
11         //请求一个互斥量锁
12         WaitForSingleObject(hMutex, INFINITE);
13         cout << "A Thread Fun Display!" << endl;
14         Sleep(100);
15         //释放互斥量锁
16         ReleaseMutex(hMutex);
17     }
18     return 0L;//表示返回的是long型的0
19 
20 }
21 
22 int main()
23 {
24     //创建一个子线程
25     HANDLE hThread = CreateThread(NULL, 0, Fun, NULL, 0, NULL);
26     hMutex = CreateMutex(NULL, FALSE,"screen");
27     //关闭线程
28     CloseHandle(hThread);
29     //主线程的执行路径
30     for (int i = 0; i < 10; i++)
31     {
32         //请求获得一个互斥量锁
33         WaitForSingleObject(hMutex,INFINITE);
34         cout << "Main Thread Display!" << endl;
35         Sleep(100);
36         //释放互斥量锁
37         ReleaseMutex(hMutex);
38     }
39     return 0;
40 }