
#include <iostream>
#include<opencv2\highgui\highgui.hpp>
#include <opencv2\core\core.hpp>
#include <opencv2\imgproc\imgproc.hpp>

using namespace std;
using namespace cv;

void DrawEllipse(Mat img, unsigned int x, unsigned int y, unsigned int a, unsigned int b, unsigned int angle);
void rectdrawn(Mat img);
void LINE(Mat img);
void shixinyuan(Mat img);
void kongxinyuan(Mat img);
void shixindian(Mat img);
void kongxindian(Mat img);

int main()
{
int width = 720;
int length = 960;
Mat ellipingimg = Mat::zeros(width,length,CV_8UC3);
DrawEllipse(ellipingimg,300,250,100,75,40);
rectdrawn(ellipingimg);
LINE(ellipingimg);
shixinyuan(ellipingimg);
kongxinyuan(ellipingimg);
shixindian(ellipingimg);
kongxindian(ellipingimg);

imshow("hua tu",ellipingimg);
waitKey(0);
return 0;
}

void DrawEllipse(Mat img, unsigned int x, unsigned int y, unsigned int a, unsigned int b, unsigned int angle)
{
	int thickness = 2;
	int lineType = 8;
	ellipse(img,Point(x,y),Size(a,b),angle,0,360,Scalar(0,255,0),thickness,lineType);
}

void rectdrawn(Mat img)
{
int x = 100;
int y = 100;
int longdata = 100;
int highdata = 100;
rectangle(img,Point(x,y),Point(x+longdata,y+highdata),Scalar(0, 255, 255), 2, 8);
}

void LINE(Mat img)
{
	line(img,Point(100,100),Point(250,250),Scalar(0,0,255),5,CV_AA);
}

void shixinyuan(Mat img)
{
Point p3(300, 300);
circle(img,p3,100,Scalar(0,0,255),3);
}

void kongxinyuan(Mat img)
{
	Point p4;
	p4.x = 400;
	p4.y = 400;
	circle(img, p4, 100, Scalar(120, 120, 120), - 1);
}

void shixindian(Mat img)
{
Point p2;
p2.x = 100;
p2.y = 100;
//画实心点
circle(img, p2, 3,Scalar(255,0,0),-1); 
}

void kongxindian(Mat img)
{
	Point p(20, 20);
	circle(img, p, 2, Scalar(0, 255, 0));
}