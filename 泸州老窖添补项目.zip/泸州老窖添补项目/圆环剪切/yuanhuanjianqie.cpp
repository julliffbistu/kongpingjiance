#include"opencv2/opencv.hpp"
//#include "opencv2/imgproc/imgproc.hpp"
#include <cxcore.h>

#define PI 3.1415926

using namespace std;
using namespace cv;

Mat dsthuan;
Mat jiequyuanhuan(Mat &img,  Point circleCenter, Mat &dst  );

int main()
{
Mat	Img = imread("123.bmp");
Point yuanCenter(400,400);
jiequyuanhuan(Img,yuanCenter,dsthuan);
imshow("image",Img);
imshow("dsthuan",dsthuan);
waitKey(0);
return 0;
}


Mat jiequyuanhuan(Mat &img,  Point circleCenter, Mat &dst  )
	{
		
		Mat dst_xiao = Mat::zeros(img.size(), img.type());
		Mat mask_xiao = Mat::zeros(img.size(),CV_8U);
		Mat dst_da = Mat::zeros(img.size(), img.type());
		Mat mask_da = Mat::zeros(img.size(),CV_8U);

		circle(mask_xiao, circleCenter, 260, Scalar(255),-1); 
		img.copyTo(dst_xiao, mask_xiao);
		circle(mask_da, circleCenter, 330, Scalar(255),-1);
		img.copyTo(dst_da, mask_da);
		dst = dst_da - dst_xiao;
		return dst;
}