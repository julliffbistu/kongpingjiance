#include"opencv2/opencv.hpp"
#include <iostream>
#include <cxcore.h>

#define PI 3.1415926

using namespace std;
using namespace cv;

Mat dsthuan;
Mat jiequyuanhuan(Mat &img,  Point circleCenter,float R1,float R2, Mat &dst  );

int main()
{
	while(1)
	{
Mat	Img = imread("123.bmp");
Point yuanCenter(400,400);     //圆心坐标
float xiaobanjing = 300;            //小圆半径
float dabanjing = 400;                //大圆半径
jiequyuanhuan(Img,yuanCenter,xiaobanjing,dabanjing,dsthuan);
imshow("image",Img);
imshow("dst",dsthuan);

float b = 0.990001 + (rand()/(double)(RAND_MAX))/100; //0-1的随机数
cout<<"BBBBBB:"<<b<<endl;

waitKey(30);
	}
	return 0;
}


Mat jiequyuanhuan(Mat &img,  Point circleCenter,float R1,float R2, Mat &dst  )
	{
		
		Mat dst_xiao = Mat::zeros(img.size(), img.type());
		Mat mask_xiao = Mat::zeros(img.size(),CV_8U);
		Mat dst_da = Mat::zeros(img.size(), img.type());
		Mat mask_da = Mat::zeros(img.size(),CV_8U);

		circle(mask_xiao, circleCenter, R1, Scalar(255),-1); 
		img.copyTo(dst_xiao, mask_xiao);
		circle(mask_da, circleCenter, R2, Scalar(255),-1);
		img.copyTo(dst_da, mask_da);
		dst = dst_da - dst_xiao;
		return dst;
}