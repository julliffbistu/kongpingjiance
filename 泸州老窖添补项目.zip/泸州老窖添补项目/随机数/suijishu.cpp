	float b =  rand()/(double)(RAND_MAX); //0-1的随机数
	float a =  rand()%2;  //外加1的
	float c = 24.4+a/10+ b/10;
	printf("%.4f\n",c);