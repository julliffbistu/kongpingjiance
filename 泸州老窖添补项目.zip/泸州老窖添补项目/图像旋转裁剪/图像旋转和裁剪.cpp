
#include <iostream>

#include <time.h>
#include<opencv2\highgui\highgui.hpp>
#include <opencv2\core\core.hpp>
#include <opencv2\imgproc\imgproc.hpp>

using namespace std;
using namespace cv;


string getTime()
{
	time_t timep;
	time (&timep); //��ȡtime_t���͵ĵ�ǰʱ��
	char tmp[64];
	//strftime(tmp, sizeof(tmp), "%Y-%m-%d %H:%M:%S",localtime(&timep) );//�����ں�ʱ����и�ʽ��
	strftime(tmp, sizeof(tmp), " %H:%M:%S",localtime(&timep) );//�����ں�ʱ����и�ʽ��
	return tmp;
}

int main()
{
	Mat src = imread("ceshi.jpg");
	//imshow("yuantu",src);
	double angle = 14;
	Point2f center(src.cols / 2, src.rows / 2);
	Mat rot = cv::getRotationMatrix2D(center, angle, 1);
	Rect bbox = cv::RotatedRect(center, src.size(), angle).boundingRect();
	rot.at<double>(0, 2) += bbox.width / 2.0 - center.x;
	rot.at<double>(1, 2) += bbox.height / 2.0 - center.y;
	Mat dst;
	warpAffine(src, dst, rot, bbox.size());
	//imshow("dst", dst);
	Rect rect(153, 144, 480, 330);
	Mat image_roi = dst(rect);

	string   time = getTime();
	char tmp[64];
	sprintf_s(tmp,64," %s",time);
	printf("%s\n",typeid(time).name());
	putText(image_roi,tmp,Point(100,100),CV_FONT_HERSHEY_PLAIN ,1,Scalar(255,0,0),2,8);//ƿ������
	imshow("qqoqq",image_roi);
	cout << time << endl;
	waitKey(0);
}