
#include <iostream>

#include <time.h>
#include<opencv2\highgui\highgui.hpp>
#include <opencv2\core\core.hpp>
#include <opencv2\imgproc\imgproc.hpp>

using namespace std;
using namespace cv;


string getTime()
{
	time_t timep;
	time (&timep); //获取time_t类型的当前时间
	char tmp[64];
	//strftime(tmp, sizeof(tmp), "%Y-%m-%d %H:%M:%S",localtime(&timep) );//对日期和时间进行格式化
	strftime(tmp, sizeof(tmp), " %H:%M:%S",localtime(&timep) );//对日期和时间进行格式化
	return tmp;
}

int main()
{
	while(1)
	{
		Mat src = imread("2.jpg");
		//imshow("yuantu",src);
		string   time = getTime();
		putText(src,time,Point(100,100),CV_FONT_HERSHEY_PLAIN ,1,Scalar(255,0,0),2,8);//瓶口总数
		imshow("qqoqq",src);
		cout << time << endl;
		waitKey(30);
	}
}
