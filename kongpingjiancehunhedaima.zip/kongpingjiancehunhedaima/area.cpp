#include<iostream>
#include<opencv2/opencv.hpp>
#include<vector>

using namespace cv;
using namespace std;


/**
 * ��С���˷����Բ
 * ��ϳ���Բ��Բ������Ͱ뾶����ʽ��ʾ
 * �˴���ı��� newsmth.net �� jingxing �� Graphics �������Ĵ��롣
 * ��Ȩ�� jingxing�� ��ֻ�ǰ��˹����һЩ�򵥵��޸Ĺ�����
 */
typedef complex<int> POINT;
bool circleLeastFit(const std::vector<POINT> &points, double &center_x, double &center_y, double &radius)
{
     center_x = 0.0f;
     center_y = 0.0f;
     radius = 0.0f;
     if (points.size() < 3)
     {
         return false;
     }
 
     double sum_x = 0.0f, sum_y = 0.0f;
     double sum_x2 = 0.0f, sum_y2 = 0.0f;
     double sum_x3 = 0.0f, sum_y3 = 0.0f;
     double sum_xy = 0.0f, sum_x1y2 = 0.0f, sum_x2y1 = 0.0f;
 
     int N = points.size();
     for (int i = 0; i < N; i++)
     {
         double x = points[i].real();
         double y = points[i].imag();
         double x2 = x * x;
         double y2 = y * y;
         sum_x += x;
         sum_y += y;
         sum_x2 += x2;
         sum_y2 += y2;
         sum_x3 += x2 * x;
         sum_y3 += y2 * y;
         sum_xy += x * y;
         sum_x1y2 += x * y2;
         sum_x2y1 += x2 * y;
     }
 
     double C, D, E, G, H;
     double a, b, c;
 
     C = N * sum_x2 - sum_x * sum_x;
     D = N * sum_xy - sum_x * sum_y;
     E = N * sum_x3 + N * sum_x1y2 - (sum_x2 + sum_y2) * sum_x;
     G = N * sum_y2 - sum_y * sum_y;
     H = N * sum_x2y1 + N * sum_y3 - (sum_x2 + sum_y2) * sum_y;
     a = (H * D - E * G) / (C * G - D * D);
     b = (H * C - E * D) / (D * D - G * C);
     c = -(a * sum_x + b * sum_y + sum_x2 + sum_y2) / N;
 
     center_x = a / (-2);
     center_y = b / (-2);
     radius = sqrt(a * a + b * b - 4 * c) / 2;
     return true;
}





int main()
{
	Mat srcImage = imread("bottle.bmp");
	imshow("��ԭͼ��", srcImage);

	//���ȶ�ͼ����пռ��ת��
	Mat grayImage;
	cvtColor(srcImage, grayImage, CV_BGR2GRAY);
	//�ԻҶ�ͼ�����˲�
	Mat thresholdImage;
	threshold(grayImage,thresholdImage,180,255,0 );
	imshow("����ֵ��������",thresholdImage);


	float GetDistance(Point2f p1, Point2f p2)
	{
		float dis = sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
		return dis;
	}



	float ComputeVariance(std::vector<cv::Point> theContour, Point2f theCenter)
	{
		int n = theContour.size();
		vector<int> a(n);

		float aver,s;
		float sum = 0, e = 0;

		for(int i = 0; i < n; i++)
		{
			a[i] = GetDistance(theContour[i],theCenter);
			sum += a[i];
		}
		aver = sum / n;
		for(int i = 0; i < n; i++)
			e += (a[i] - aver) * (a[i] - aver);
		e /= n - 1;
		s = sqrt(e);
		return e;
	}



	vector<Point3f> FindCircles(Mat img, int minPoints, int maxOffset, int minr, int maxr)
	{
		vector<Point3f> result;
		vector<vector<Point> > contours;
		vector<Vec4i> hierarchy;

		findContours( img.clone(), contours, hierarchy, CV_RETR_CCOMP, CV_CHAIN_APPROX_SIMPLE );

		for (int i = 0; i < contours.size(); i++)
		{
			Point2f center; float radius;  
			if (contours[i].size() > minPoints)
			{
				minEnclosingCircle(contours[i], center, radius);//�õ���С���ԲԲ�ĺͰ뾶  
				int offset = ComputeVariance(contours[i], center);
				if (offset < maxOffset && radius > minr && radius <= maxr)
				{
					Point3f p(center.x, center.y, radius);
					result.push_back(p);
				}
			}
		}

		return result;
	}

	
	
	int minr = 0;
	int maxr = 100;
	vector<Point3f> circles = FindCircles(thresholdImage, 50, 80, 0, 100);//�����
	for (int i = 0; i < circles.size(); i++)
	{
		circle(thresholdImage, Point(circles[i].x, circles[i].y), circles[i].z, Scalar(0,0,255), 2, 8, 0);
	}

	imshow("�����", thresholdImage);








	
	//blur(thresholdImage,thresholdImage,Size(3,3));
	//imshow("���˲����ͼ��", thresholdImage);
	
	
	/*-----------------------------------------------------------------------------------------------
	Mat element = getStructuringElement(MORPH_ELLIPSE,Size(3,3));
	for(int i=0;i<3;i++)
	{
		erode(thresholdImage,grayImage,element);
		//dilate(grayImage,grayImage,element);
	}
	imshow("��ʴ���ͺ�ͼ��",grayImage);
	-----------------------------------------------------------------------------------------------*/
	//Mat cannyImage;
	//Canny(grayImage, cannyImage, 300, 900, 3);
	//�ڵõ��Ķ�ֵͼ����Ѱ������
	vector<vector<Point>> contours;
	vector<Vec4i> hierarchy;
	findContours(grayImage, contours, hierarchy, CV_RETR_CCOMP, CHAIN_APPROX_SIMPLE, Point(0, 0));

	//��������
	for (int i = 0; i < (int)contours.size(); i++)
	{
		Scalar color(rand() & 255, rand() & 255, rand() & 255);
		drawContours(grayImage, contours, i, Scalar(255), 1, 8,hierarchy);
	}

	imshow("���������ͼ��", grayImage);



	//�������������
	for (int i = 0; i < (int)contours.size(); i++)
	{
		double g_dConArea = contourArea(contours[i], true);
	//	cout << "��������������㺯����������ĵ�" << i << "�����������Ϊ����" << g_dConArea << endl;
	}

	waitKey(0);

	return 0;
} 