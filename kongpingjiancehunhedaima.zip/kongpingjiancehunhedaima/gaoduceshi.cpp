
#include"opencv2/opencv.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <iostream>
using namespace cv;
using namespace std;

int main()
{
	Mat img = imread("333.jpg");//ԭͼ
	Mat img2 = imread("333.jpg");//ԭͼ
	if (!img.data)
	{
		printf("������û�и�ͼƬ\n");
		return false;
	}
	//imshow("yuantu",img);
	Mat cvtColor_output;//�Ҷ�ͼ
	cvtColor(img, cvtColor_output, CV_BGR2GRAY);
	Mat threshold_output;//��ֵͼ
	threshold(cvtColor_output, threshold_output, 90, 255, CV_THRESH_BINARY);  //100�����޸ģ����ڶ�ֵ������
	//imshow("��ֵ�����",threshold_output);

	//blur(threshold_output,threshold_output,Size(3,3));
	//imshow("blurzhihou",threshold_output);

	Mat edges;
	Canny(threshold_output,edges,1, 5,5);
	//imshow("Canny",edges);
	//cout<<edges<<endl;
	//----------------------------------------׿��ɨ��-----------------------------------------------------------
	int n =0;
	//ƿ��ƿ�ڱ�Ե����
	for (int i = 0;i<edges.rows;i++)
	{
		int acount=0;
		for (int j = 0;j<edges.cols;j++)
		{
			if(edges.at<uchar>(i,j) == 255) 
			{
				acount++;

			}

			if(acount>70)
			{
				cout<<"�������Ϊ"<<acount<<endl;
				cout<<"�к�Ϊ��"<<i<<endl;
				n++;
				
				//----------------------------------------�ж�ƿ�Ӹߵ�------------------------------------------------------------------------------						
				int bottle_height_regularsize = 37;//�궨ƿ�ڸ߶����غ���ԭ�ߴ�  �߶�����������1mm
				int bottle_errorsize= 0.5; //1mm��ռ������ֵ        
				if (i<(bottle_height_regularsize-bottle_errorsize))
				{
					printf("This bottle is lower than the standard bottle\n");
					return 0;
				}
				else if(i>(bottle_height_regularsize+bottle_errorsize))
				{
					printf("This bottle is taller than the standard bottle\n");
					return 0;
				}
				else
				{
					printf("This bottle is a standard bottle\n");
				}
				
				
				
				//--------------------------------------ƿ�Ӹߵ��жϽ���-------------------------------------------------------------------------------						
			}
			if(n>0)
				{
					break;
				}
		}		
	}

	imshow("yuantu",img2);
	waitKey(0);
}