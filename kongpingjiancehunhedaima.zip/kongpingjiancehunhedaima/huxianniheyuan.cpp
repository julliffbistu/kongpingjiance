
#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

void DrawFilledCircle(Mat img, Point center,int _radius)
{
	int thickness = -1;
	int lineType = 8;
	circle(img,
		center,
		_radius,
		Scalar(0, 0, 255),
		5,
		lineType);
}




int main()
{
	Mat img=imread("huang.jpg");

	if (img.empty())
	{
		std::cout<<"Could not load image file!";
		system("pause");
		return 0;
	}
	else
	{
		//unsigned char M = 0;
		int N=0;
		int row, col;
		int height, width, step, channels;
		int i, j;

		height = img.rows;
		width = img.cols;
		step = img.step;
		channels = img.dims;
		std::cout << "Processing a " << height << "*" << width << "image with" << channels << "channels and" << step << "steps" << endl;

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////////��ȡ���Ҷ�ֵ���ص�����////////////////////////////////////////////////////////////////
		for (i = 0; i<height; i++)
			for (j = 0; j<width; j++)
				if (img.data[i*step + j]>N)
				{
					N = img.data[i*step + j];
					row = j; col = i;
				}
				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				/////////////////////////////////////////////////////////////////////////��ͼ����ж�ֵ��////////////////////////////////////////////////////////////

				std::cout << "the centure is" <<row<<"*"<<col<<endl;
				std::cout << "pixel value is" << N <<endl; 

				DrawFilledCircle(img, Point(row,col),100);

				namedWindow("��Բ", CV_WINDOW_NORMAL); //��������,����Ĳ�����ʾ���Ե������ڵĴ�С
				imshow("��Բ", img);
	}
	cvWaitKey();
	return 0;
}