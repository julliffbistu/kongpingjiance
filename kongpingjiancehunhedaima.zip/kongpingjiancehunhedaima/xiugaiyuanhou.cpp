#include <iostream>
#include "putText.h"
//#include "MySerial.h"
#include"opencv2/opencv.hpp"
#include "opencv2/imgproc/imgproc.hpp"


int bottle_sum = 0, impurity_sum = 0, just1 = 0, just2 = 0;
int Damaged_quantity_number = 0, impurity_quantity_number = 0;
float Damaged_quantity_number_rate = 0, impurity_quantity_number_rate = 0;
float  outer_circular_degree = 0, inner_circular_degree = 0;
#define PI 3.1415926
int grade_level = 286, gread = 0;


using namespace cv;
using namespace std;


int main()
{
	Mat dst_bu = imread("backgroundbuchong.png");
//	Serial_open(_T("COM3"), 9600);
	//double Time = (double)cvGetTickCount();
		float INNERCircle_radius=0, OUTCircle_radius=0;
		Mat image_roi, gray, threshold_out, cimage, cvtColor_output, threshold_output, out_image;
		int tichu_sum = 0;
		Point center;
		Size axes;
		vector<vector<Point>> contours;
		vector<Vec4i> hierarchy;

	while (1)
	{  
		double Time = (double)cvGetTickCount();
		Mat IMG = imread("C:\\Users\\zhulifu\\Desktop\\sanpai\\ceshi8.bmp");   ////,6,8��Ҫ��Ҫ����Ϊ3��ƿ�Ӱڷ������⡣������û�¡�
		Mat img = imread("C:\\Users\\zhulifu\\Desktop\\sanpai\\pingdi\\pingdi.bmp");//ԭͼ 
		
		Mat dst = imread("background.png");
		int height = IMG.rows;
		int width = IMG.cols;
		int height_high = img.rows;
		int width_high = img.cols;
	




		if (!img.data && !IMG.data)
		{
			printf("������û�и�ͼƬ\n");
			return false;
		}

		Rect rect2(350, 150, 850, 850);  //1,2λ������㣬���ĺ�λ�ǿ�ȡ���������Ҫ�궨 850
		image_roi = IMG(rect2);
		//imshow("jieququyu",image_roi);


		if (!image_roi.data == 0)
		{
			bottle_sum++;
			cvtColor(image_roi, gray, CV_BGR2GRAY);      //��imageת���ɻҶȷŵ�gray��
			threshold(gray, threshold_out, 170, 255, CV_THRESH_BINARY);    //��ֵ�����Ӱ����Բ��� 
			//imshow("qqwqwq",threshold_out);

			float midel_radius = 0, large_radius = 0, small_radius = 0;
			findContours(threshold_out, contours, hierarchy, CV_RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0));
			cimage = Mat::zeros(threshold_out.size(), CV_8UC3);
			for (size_t i = 0; i < contours.size(); i++)
			{
				size_t count = contours[i].size();//��ϵĵ�����Ϊ6
				if (count < 550)   //ȥ����ԲС��һ��������Բ,�����
					continue;
				RotatedRect box = fitEllipse(contours[i]);//��Բ���
				center.x = cvRound(box.center.x);     /*ȷ����Բbox��ֵcenter��size��angle*/
				center.y = cvRound(box.center.y);

				axes.width = cvRound(box.size.width*0.5);
				axes.height = cvRound(box.size.height*0.5);
				box.angle = -box.angle;

				if (abs(axes.width - axes.height)<3)         //��϶��Բ���趨����������ȷ����Ҫ��Բ2������������Բ�ĳ����Ტ���
				{
					drawContours(cimage, contours, (int)i, Scalar::all(255), 1, 8);
					ellipse(image_roi, box, Scalar(0, 0, 255), 4, CV_AA);
					//imshow("�����Բ���", image_roi );
					//printf("����λ�ã�x=%d,y=%d\n",axes.width,axes.height);

					midel_radius = (axes.width + axes.height) / 2;
					cout << "Բ�İ뾶Ϊ ��" << midel_radius << endl;
					float A_area = PI*axes.width*axes.height;
					float A_length = 2 * PI*axes.height + 4 * (abs(axes.width - axes.height));
					float circular_degree = (4 * PI*A_area) / (A_length*A_length);
					cout << "Բ��Ϊ��" << circular_degree << endl;

					if (midel_radius >240 && midel_radius<270)               //��������߶ȵ��ڵĲ�������Ҫ�궨huantujiugai
					{
						small_radius = midel_radius;
						inner_circular_degree = circular_degree;
					}
					else if (midel_radius > 270)
					{
						large_radius = midel_radius;
						outer_circular_degree = circular_degree;
					}

					cout << "-------------------------------------����������Բ����-----------------------------------------\n" << endl;
				}
			}
			cout << "small is :" << small_radius << "\n" << "large is :" << large_radius << "\n" << endl;
			//------------------------------------------------�����⾶-------------------------------------------------------------
			if (small_radius == 0 || large_radius == 0)
			{
				printf("this is a broken bottle !");
				Damaged_quantity_number++;
				//just1 = 1;
		//		Serial_write("11", sizeof("aa") - 1);
			}
			else
			{
				float INNERstanderd_bottle_r = 17.6, OUTstanderd_bottle_r = 25.6;
				float pixcel_area = 0.04339; //�궨
				INNERCircle_radius = small_radius*pixcel_area * 2 - 3.5743;
				OUTCircle_radius = large_radius*pixcel_area * 2; //�궨��ֵ
				cout << "��Բ�İ뾶Ϊ ��" << inner_circular_degree << endl;
				cout << "��Բ�İ뾶Ϊ ��" << outer_circular_degree << endl;
				//just1 = 1;
			}
			float Damaged_quantity_number1 = Damaged_quantity_number;
			float bottle_sum1 = bottle_sum;
			Damaged_quantity_number_rate = (Damaged_quantity_number1 / bottle_sum1) * 100;
		}
		printf("**************************  ƿ�ڼ�����*********************************");/////////////////////////////////	

		if (!img.data == 0)
		{
			impurity_sum++;
			Rect rect(280, 250, 950, 750);  //1,2λ������㣬���ĺ�λ�ǿ��
			img = img(rect);//
			//imshow("yuantu",img);

			cvtColor(img, cvtColor_output, CV_BGR2GRAY);
			threshold(cvtColor_output, threshold_output, 200, 255, CV_THRESH_BINARY);  //100�����޸ģ����ڶ�ֵ������
			//imshow("threshold_output",threshold_output);
			bitwise_not(threshold_output, threshold_output);
			//imshow("threshold_output1",threshold_output);

			findContours(threshold_output, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_NONE);
			//cout << "num=" << contours.size() << endl;
			double area = 0;
			int i;
			double area_max = contourArea(contours[0]);
			//cout<<"-----------"<<area_max<<endl;
			for (i = 0; i<contours.size(); i++)
			{
				drawContours(img, contours, i, Scalar(0, 0, 255), 4, 8);
				area = contourArea(contours[i]);//�����i�����������
				//cout<<"area"<<area<<endl;
				if (area_max > area)
				{
					area_max = area_max;
				}
				else
				{
					area_max = contourArea(contours[i]);
				}
			}
			cout << "\n area_max is :" << area_max << endl;

			if (area_max > 20)
			{
				printf("There has impurity at the bottom of the bottle.");
				impurity_quantity_number++;
				just2 = 1;
		//		Serial_write("00", sizeof("aa") - 1);
			}
			else
			{
				printf("There is no impurity at the bottom of the bottle.\n");

				//impurity_quantity_number++;
			}
			float impurity_quantity_number1 = impurity_quantity_number;
			float impurity_sum1 = impurity_sum;
			impurity_quantity_number_rate = (impurity_quantity_number1 / impurity_sum1) * 100;
		}

		resize(image_roi, image_roi, Size(image_roi.cols / 2.69, image_roi.rows / 2.68), 0, 0, INTER_LINEAR);
		resize(img, img, Size(img.cols/3, img.cols/4), 0, 0, INTER_LINEAR);

		image_roi.copyTo(dst(Rect(84, 283, image_roi.cols, image_roi.rows)));
		img.copyTo(dst(Rect(84, 634, img.cols, img.rows)));
		out_image = dst;

		//putTextZH(out_image, "��ԲԲ�ȣ�", Point(700, 707), Scalar(0, 0, 0), 18, "����");
		char buf[256];

		sprintf_s(buf, 256, "%d", bottle_sum);
		putText(out_image, buf, Point(546, 376), CV_FONT_HERSHEY_PLAIN, 1.3, Scalar(0, 0, 0), 2, 8);//ƿ������
		sprintf_s(buf, 256, "%d", impurity_sum);
		putText(out_image, buf, Point(546, 723), CV_FONT_HERSHEY_PLAIN, 1.3, Scalar(0, 0, 0), 2, 8);//��������

		sprintf_s(buf, 256, "%d", Damaged_quantity_number);
		putText(out_image, buf, Point(779, 376), CV_FONT_HERSHEY_PLAIN, 1.3, Scalar(0, 0, 0), 2, 8);//������
		sprintf_s(buf, 256, "%d", impurity_quantity_number);
		putText(out_image, buf, Point(779, 723), CV_FONT_HERSHEY_PLAIN, 1.3, Scalar(0, 0, 0), 2, 8);//������

		sprintf_s(buf, 256, "%.2f", INNERCircle_radius);
		putText(out_image, buf, Point(779, 443), CV_FONT_HERSHEY_PLAIN, 1.3, Scalar(0, 0, 0), 2, 8);//�ڲ��뾶
		sprintf_s(buf, 256, "%.2f", OUTCircle_radius);
		putText(out_image, buf, Point(546, 443), CV_FONT_HERSHEY_PLAIN, 1.3, Scalar(0, 0, 0), 2, 8);//�ⲿ�뾶

		sprintf_s(buf, 256, "%f", inner_circular_degree);
		putText(out_image, buf, Point(779, 510), CV_FONT_HERSHEY_PLAIN, 1.3, Scalar(0, 0, 0), 2, 8);  //Բ��
		sprintf_s(buf, 256, "%f", outer_circular_degree);
		putText(out_image, buf, Point(546, 510), CV_FONT_HERSHEY_PLAIN, 1.3, Scalar(0, 0, 0), 2, 8);  //Բ��

		if (just1 == 1)
		{
			putTextZH(out_image, "ƿ������", Point(546, 560), Scalar(0, 0, 0), 18, "����");
		}
		if (just1 == 0)
		{
			putTextZH(out_image, "ƿ��������", Point(546, 560), Scalar(0, 0, 0), 18, "����");
		}
		if (just2 == 1)
		{
			putTextZH(out_image, "ƿ��������", Point(546, 828), Scalar(0, 0, 0), 18, "����");
		}
		if (just2 == 0)
		{
			putTextZH(out_image, "ƿ��������", Point(546, 828), Scalar(0, 0, 0), 18, "����");
		}

		sprintf_s(buf, 256, "%0.2f%%", Damaged_quantity_number_rate);
		putText(out_image, buf, Point(779, 579), CV_FONT_HERSHEY_PLAIN, 1, Scalar(0, 0, 0), 2, 8);  //������

		sprintf_s(buf, 256, "%0.2f%%", impurity_quantity_number_rate);
		putText(out_image, buf, Point(779, 845), CV_FONT_HERSHEY_PLAIN, 1, Scalar(0, 0, 0), 2, 8);  //������		
		//------------------------------------------�б�----------------------------------------------------

		if (just1 == 1)
		{
			putTextZH(dst_bu, "����", Point(84, grade_level + 54), Scalar(0, 0, 0), 18, "����");
			grade_level = grade_level + 54;
		}
		if (just2 == 1)
		{
			putTextZH(dst_bu, "����", Point(84, grade_level + 54), Scalar(0, 0, 0), 18, "����");
			grade_level = grade_level + 54;
		}
		if (grade_level>854)
		{
			grade_level = 286;
			dst_bu = imread("backgroundbuchong.png");
		}

		dst_bu.copyTo(out_image(Rect(939, 0, dst_bu.cols, dst_bu.rows)));
		//-----------------------------------------------------------------------------------------------------				
		resize(out_image,out_image,Size(800,600));
		//imshow("�� �� �� ѧ Ժ �� �� �� �� �� ��", out_image);
		
		//namedWindow("FullScreen", CV_WINDOW_NORMAL);
		//setWindowProperty("FullScreen", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
		imshow("FullScreen", out_image);
		Time = (double)cvGetTickCount() - Time;
		printf("run time = %gms\n", Time / (cvGetTickFrequency() * 1000));
		//putTextZH(out_image, "ƿ  ��  nei", Point(65, 683), Scalar(0, 255, 0), 26, "����");
		//putTextZH(out_image, "�������廻...\n�У�б�壬�»��ߣ���ʾ!", Point(50, 200), Scalar(128, 255, 0), 30, "����", true, true);
		waitKey(1);
		//destroyAllWindows();
		//	setWindowProperty("�� �� �� ѧ Ժ �� �� �� �� �� ��", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);//����������ȫ��
	}
}
