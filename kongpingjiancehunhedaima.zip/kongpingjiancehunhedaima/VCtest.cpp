#include<iostream>
using namespace std;

int main()
{
	int a=0;
	cin>>a;
cout<<"hello world:"<<a<<endl;
}