#include"opencv2/opencv.hpp"
#include "opencv2/imgproc/imgproc.hpp"

using namespace cv;
using namespace std;



RNG rng(12345);

int main()
{
	double Time = (double)cvGetTickCount();
	//VideoCapture capture(0);
	//waitKey(200);
	Mat medianBlur_out,cvtColor_out,threshold_out,canny_out;
		//capture >> frame;
	Mat	frame = imread("huang2.jpg");
	//imshow("sourefig",frame);
		//--------------------------------------------------------------------------------------------------------------------
		medianBlur(frame,medianBlur_out,5);
		cvtColor(medianBlur_out,cvtColor_out,COLOR_BGR2GRAY);

		threshold(cvtColor_out,threshold_out,250,255,3 );
	 	imshow("����ֵ��������",threshold_out);
		
		//Canny(threshold_out, canny_out, 128, 255, 3);

		Mat threshold_output;

		vector<vector<Point>> contours;
		vector<Vec4i> hierarchy;
		double g_dConLength[1000];
		findContours(threshold_out, contours, hierarchy, CV_RETR_EXTERNAL, CHAIN_APPROX_SIMPLE, Point(0, 0));
		//��������
		/*for (int i = 0; i < (int)contours.size(); i++)
		{
			drawContours(threshold_out, contours, -8, Scalar(255), 1, 8);
			g_dConLength[i] = arcLength(contours[i], true);
			//cout << "�����������ȼ��㺯����������ĵ�" << i << "�������ĳ���Ϊ����" << g_dConLength[i] << endl;	
	
			
		}
		//cout<<"max:"<<g_dConLength[0]<<endl;
		//imshow("���������ͼ��", threshold_out);


		
		/*vector<RotatedRect> minRect(contours.size());
		vector<RotatedRect> minEllipse(contours.size());

		for (int i = 0; i < contours.size(); i++)
		{
			minRect[i] = minAreaRect(Mat(contours[i]));
			if (contours[i].size() > 5)
			{
				minEllipse[i] = fitEllipse(Mat(contours[i]));
			}
		}

		/// ��������������б�ı߽��ͱ߽���Բ
		Mat drawing = Mat::zeros(threshold_output.size(), CV_8UC3);
		for (int i = 0; i< contours.size(); i++)
		{
			Scalar color = Scalar(rng.uniform(0, 255), rng.uniform(0, 255), rng.uniform(0, 255));
			// contour
			drawContours(frame, contours, i, color, 1, 8, vector<Vec4i>(), 0, Point());
			// ellipse
			ellipse(frame, minEllipse[i], color, 2, 8);
			// rotated rectangle
			Point2f rect_points[4]; minRect[i].points(rect_points);
			for (int j = 0; j < 4; j++)
				line(frame, rect_points[j], rect_points[(j + 1) % 4], color, 1, 8);
		}
		namedWindow("Contours", CV_WINDOW_AUTOSIZE);
		imshow("Contours", frame);*/





	
/*
		//���������ĳ���
		double g_dConLength[1000];
		for (int i = 0; i < (int)contours.size(); i++)
		{
			 g_dConLength[i] = arcLength(contours[i], true);
			cout << "�����������ȼ��㺯����������ĵ�" << i << "�������ĳ���Ϊ����" << g_dConLength[i] << endl;
		
		if (g_dConLength[0]<g_dConLength[i])
			{
				g_dConLength[0] = g_dConLength[i];
			}
		}
		cout<<"max:"<<g_dConLength[0]<<endl;
		
		//drawContours(threshold_out, contours[0], 1, Scalar(255), 1, 8);
		//imshow("contours[i]", threshold_out);*/



	waitKey(0);
     
	Time = (double)cvGetTickCount() - Time ;
	printf( "run time = %gms\n", Time /(cvGetTickFrequency()*1000) );
	return 0;
}