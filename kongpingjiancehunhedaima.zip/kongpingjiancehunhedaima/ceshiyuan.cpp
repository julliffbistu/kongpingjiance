#include "FindCircles.h"
#include"opencv2/opencv.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <iostream>
using namespace cv;
using namespace std;

void main()
{
    Mat img = imread("louxia3.jpg");//ԭͼ
	imshow("yuantu",img);
    Mat cvtColor_output;//�Ҷ�ͼ
    cvtColor(img, cvtColor_output, CV_BGR2GRAY);
    Mat threshold_output;//��ֵͼ
    threshold(cvtColor_output, threshold_output, 180, 255, CV_THRESH_BINARY);
	imshow("��ֵ�����",threshold_output);
    Mat Canny_output;
	Canny(threshold_output,Canny_output,3,9,3);
	imshow("Canny�����",Canny_output);

	//Mat dstImage = Mat::zeros(threshold_output.rows,threshold_output.cols,CV_8UC3);
	//threshold_output = threshold_output > 100;
	//imshow("��ȡ��ֵ���ԭʼͼ��",threshold_output);
	//---------------------------------------------------�����νṹ----------------------------------------------------------
	vector<vector<Point>> contours;
	vector<Vec4i> hierarchy;
	//---------------------------------------------------��������--------------------------------------------------------------
	findContours(threshold_output,contours,hierarchy,CV_RETR_EXTERNAL,CV_CHAIN_APPROX_SIMPLE);
	int index = 0;
	for ( ; index >= 0;index = hierarchy[index][0])
	{
		Scalar color(255,255,255);
		//Scalar color(rand()&255,rand()&255,rand()&255);//�����ɫ
		drawContours(threshold_output,contours,index,color,CV_RETR_CCOMP,1,hierarchy);
	}
		imshow("������ͼ��",threshold_output);
	
	/*int minr = 200;
    int maxr = 400;
    vector<Point3f> circles = FindCircles(threshold_output, 500, 100, 100, 240);//�����
    for (int i = 0; i < circles.size(); i++)
    {
        circle(img, Point(circles[i].x, circles[i].y), circles[i].z, Scalar(0,0,255), 2, 8, 0);
    }
 
    imshow("�����",img);*/
    waitKey(0);
}
