#include <iostream>
#include "opencv2/opencv.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"

using namespace std;
using namespace cv;

#define WINDOW_NAME "�����򴰿ڡ�"

int g_nThresholdValue = 200;
int g_nThresholdType = 3;
Mat g_srcImage,g_grayImage,g_dstImage;

//static void ShowHelpText();
void on_Threshold(int,void*);

int main()
{   
	

	g_srcImage = imread("bottle.bmp");
	cvtColor(g_srcImage,g_grayImage,COLOR_RGB2GRAY);
	//cvNameWindow(WINDOW_NAME,WINDOW_AUTOSIZE);
	//createTrackbar("moshi",WINDOW_NAME,&g_nThresholdType,4,on_Threshold);
	//createTrackbar("canshuzhi",WINDOW_NAME,&g_nThresholdValue,255,on_Threshold);

	on_Threshold(0,0);
	while(1)
	{
		int key;
		key = waitKey(20);
		if((char)key == 27){break;}
	}
}
void on_Threshold(int, void*)
{
	threshold(g_grayImage,g_dstImage,g_nThresholdValue,155,g_nThresholdType);
	imshow(WINDOW_NAME,g_dstImage);
}

  Canny(g_srcImage,edges_out,120, 360,3);