
#define  MAX_CAMERA 6

