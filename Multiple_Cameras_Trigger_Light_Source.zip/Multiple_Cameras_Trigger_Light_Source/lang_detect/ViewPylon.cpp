#include "StdAfx.h"
#include "ViewPylon.h"
#include "stdio.h"
#include "atlstr.h"
#include <locale.h>

using namespace GenApi;
using namespace Pylon;

ViewPylon::ViewPylon(void)
{
}

// Instant Camera Image Event.
// This is where we are going the receive the grabbed images.
// This method is called from the Instant Camera grab loop thread.
void ViewPylon::OnImageGrabbed( CInstantCamera& camera, const CGrabResultPtr& ptrGrabResult)
{
	CvMat Mul;
	CString Buffer;
	if (ptrGrabResult->GrabSucceeded())
    {
		//if(m_PixelFormat == PixelType_Mono8)
			Mul = cvMat(ptrGrabResult->GetHeight(),ptrGrabResult->GetWidth(),CV_8UC1,(unsigned char*)ptrGrabResult->GetBuffer());
		//else
		//	Mul_Image[0] = cvMat(ptrGrabResult->GetHeight(),ptrGrabResult->GetWidth(),CV_8UC3,(unsigned char*)ptrGrabResult->GetBuffer());
		
		Buffer.Format ("orig.jpg");
		cvSaveImage((String_t)Buffer,&Mul);
	}
}

// Instant Camera Configuration Event.
// This method is called from the Instant Camera grab loop thread.
void ViewPylon::OnGrabError( CInstantCamera& camera, const char* errorMessage)
{
}

// Instant Camera Configuration Event.
// This method is called from additional Instant Camera thread.
void ViewPylon::OnCameraDeviceRemoved( CInstantCamera& camera)
{
}
