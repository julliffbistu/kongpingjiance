#include "macro_define.h"
#include "cv.h"
#include "cxcore.h"
#include "highgui.h"
#include "imgproc\imgproc.hpp"

using namespace cv;

extern int m_max_cameras;

extern int m_WidthControl;
extern int m_HeightControl;
extern int m_OffsetXControl;
extern int m_OffsetYControl;
extern int64_t m_ExposureTimeControl;
extern int64_t m_HeartbeatTimeoutControl;

extern CvMat Image_Mat[MAX_CAMERA];
extern int image_grab_done[MAX_CAMERA];
