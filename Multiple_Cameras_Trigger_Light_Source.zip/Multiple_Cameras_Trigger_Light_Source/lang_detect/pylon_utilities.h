#ifndef INCLUDE_UCCA_UTILITIES_H
#define INCLUDE_UCCA_UTILITIES_H

#include <pylon/PylonIncludes.h>
#include "BvcDib.h"

using namespace Pylon;
using namespace GenApi;
using namespace std;
using namespace Bvc;

#include <windows.h>
#include <vector>

/*
* \brief Automatic locking of block statements 
* 
* class T requirements are the functions void Lock() and void Unlock().
*/
template<class T> 
class CAutoLock
{
  T& m_LockingObject;
public:
  CAutoLock( T& obj )
    : m_LockingObject( obj )
  {
    m_LockingObject.Lock();
  }
  ~CAutoLock()
  {
    m_LockingObject.Unlock();
  }
};


class CStopWatch
{
  public:
    /// Constructor, starts time measurement
    CStopWatch(){ Start(); }

    /// Start the stop watch 
    void Start(){ QueryPerformanceCounter(&m_StartTime); }

    /// Stop. The elapsed time is returned. The stop watch may be started again
    double Stop(bool StartAgain)
    {
        QueryPerformanceCounter(&m_StopTime);
        double theElapsedTime = ElapsedTime();
        if(StartAgain)
            m_StartTime = m_StopTime; 
        return theElapsedTime;
    }

    /// Return the elapsed time in seconds between start() and stop()
    double ElapsedTime()
    {
        LARGE_INTEGER timerFrequency;
        QueryPerformanceFrequency(&timerFrequency);

        __int64 oldTicks = ((__int64)m_StartTime.HighPart << 32) + (__int64)m_StartTime.LowPart;
        __int64 newTicks = ((__int64)m_StopTime.HighPart << 32) + (__int64)m_StopTime.LowPart;
        long double timeDifference = (long double) (newTicks - oldTicks);

        long double ticksPerSecond = (long double) (((__int64)timerFrequency.HighPart << 32) 
            + (__int64)timerFrequency.LowPart);

        return (double)(timeDifference / ticksPerSecond);
    }

  private:
    /// zero-point for time measurment
    LARGE_INTEGER m_StartTime;

    /// last time stamp
    LARGE_INTEGER m_StopTime;
};


// A simple buffer class
class CGrabBuffer
{
public:
    CGrabBuffer( const size_t ImageSize );
    ~CGrabBuffer();
    uint8_t* GetBufferPointer( void ) { return m_pBuffer; }
    StreamBufferHandle GetBufferHandle( void ) { return m_hBuffer; }
    void SetBufferHandle( StreamBufferHandle hBuffer ) { m_hBuffer = hBuffer; };

protected:
    uint8_t *m_pBuffer;
    StreamBufferHandle m_hBuffer;
};


/// Wrapper for Win32 CriticalSection
class CCriticalSection
{
  /// the Win32 critical section
  CRITICAL_SECTION m_CS;
public:
  /// constructor
  CCriticalSection()
  {
    ::InitializeCriticalSection( &m_CS );
  }
  /// destructor
  ~CCriticalSection()
  {
    ::DeleteCriticalSection( &m_CS );
  }

private:
  CCriticalSection( const CCriticalSection & );           // not implemented
  CCriticalSection& operator=( const CCriticalSection& ); // not implemented
public:
  /// wait for ownership
  void Lock()
  {
    ::EnterCriticalSection( &m_CS );
  }
  /// release ownership
  void Unlock()
  {
    ::LeaveCriticalSection( &m_CS );
  }
  /// attempt to gain ownership - true if entering
  bool TryLock()
  {
#if _WIN32_WINNT >= 0x0400
    return ::TryEnterCriticalSection( &m_CS )!= 0;
#else
    assert( FALSE && _T( "TryLock not implemented" ) );
    return false;
#endif
  }

};


typedef CAutoLock<CCriticalSection> CLockc;


//! Template class to calculate a moving average
/*! \param T Type of the measurement data (typically double or float)
\param span Number of samples used of computing the mean
The class is thread safe.
*/
template <class T, unsigned int span = 10>
class CMovingAvg
{
  
public:
  //! Default constructor
  CMovingAvg() : m_v(span) 
  {
    Reset();
  }
  
  //! Add a data item to the moving average
  void Add(T sample) 
  { 
    CLockc lck( m_CritSect );
    //m_CritSect.Lock();
    int idx = m_n % span;
    if ( m_n < span )
    {
      m_v[idx] = sample;
      m_Sum += sample;
    }
    else
    {
      m_Sum -= m_v[idx];
      m_Sum += sample;
      m_v[idx] = sample;
    }
    m_n++;
  }
  
  //! Get the average
  double Avg() {
    double res = 0;
    CLockc lck( m_CritSect );
    //m_CritSect.Lock();
    if ( m_n != 0 )
    {
      res = m_n < span ? m_Sum / (double) m_n : m_Sum / (double) span;
    }
    //m_CritSect.Unlock();
    return res;
  }
  
  //! Reset the moving average clearing the history
  void Reset() {
    CLockc lck( m_CritSect );
    //m_CritSect.Lock();
    m_Sum = 0.0;
    m_n = 0;
    //m_CritSect.Unlock();
  }
  
protected:
  //! The current sum
  double m_Sum;
  
  //! Number of measurement data
  unsigned int m_n;
  
  //! Vetor holding #span data items
  std::vector<T> m_v;
  
  //! critical section guarding the access to the class
  CCriticalSection m_CritSect;
  
};

class CPylonDibPtr : public CDibPtr
{
public:
    StreamBufferHandle GetBufferHandle (void) { return m_hBuffer; }
    void SetBufferHandle (StreamBufferHandle hBuffer) { m_hBuffer = hBuffer; };

protected:
    StreamBufferHandle m_hBuffer;
};


#endif // INCLUDE_UCCA_UTILITIES_H
