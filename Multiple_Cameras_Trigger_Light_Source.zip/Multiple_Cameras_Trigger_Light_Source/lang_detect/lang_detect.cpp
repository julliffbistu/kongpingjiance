// lang_detect.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
// Include files to use the PYLON API
#include <pylon/PylonIncludes.h>
#include "varable.h"
#include "EventPrinter.h"
#include <iostream>

#include "opencv2/imgproc/imgproc.hpp"
#include"opencv2/opencv.hpp"
#include "putText.h"
int Damaged_quantity_number = 0, impurity_quantity_number = 0;
int bottle_sum = 0, impurity_sum = 0, just1 = 0, just2 = 0;
float Damaged_quantity_number_rate = 0, impurity_quantity_number_rate = 0;
float  outer_circular_degree = 0,inner_circular_degree = 0;
#define PI 3.1415926

#include <TCHAR.H>
#include "MySerial.h"
#include "cv.h"
#include "cxcore.h"
#include "highgui.h"
#include "imgproc\imgproc.hpp"

using namespace std;
using namespace cv;
using namespace Pylon;
using namespace GenApi;


DWORD WINAPI ThreadFunction1(LPVOID lpParameter);
DWORD WINAPI ThreadFunction2(LPVOID lpParameter);

int number_data = 0;
float INNERCircle_radius,OUTCircle_radius;
Point center;
Size axes;
vector<vector<Point>> contours;
vector<Vec4i> hierarchy;
Mat img,img2, IMG, image_roi, gray, threshold_out, cimage, cvtColor_output,threshold_output;
 

//Mat image_roi = Mat::zeros(height, width, CV_8UC3);//�߳�1������ͼ��
//Mat image_roi = Mat::zeros(height, width, CV_8UC3);//�߳�1�����ͼ��
//Mat img = Mat::zeros(height, width, CV_8UC3);//�߳�2�����ͼ��
//Mat img = Mat::zeros(height, width, CV_8UC3);//�߳�1������ͼ��



DWORD WINAPI ThreadFunction1(LPVOID lpParameter)
{
	cout << "�߳�1��ʼ���� ��" << endl;
	while (1)
	{
		if(image_grab_done[0]==1)
		{
			IMG = Mat(&Image_Mat[0],true);
			bottle_sum++;
			int height = IMG.rows;
			int width = IMG.cols;
			//imshow("erer",IMG);
			Rect rect2(350,150, 450,450);  //1,2λ������㣬���ĺ�λ�ǿ�ȡ���������Ҫ�궨 850
			image_roi = IMG(rect2);
			threshold( image_roi, threshold_out, 170, 255, CV_THRESH_BINARY );
			//imshow("qqwqwq",image_roi);
			
			float midel_radius = 0,large_radius = 0, small_radius = 0;
			findContours(threshold_out, contours, hierarchy, CV_RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0));
			cimage  = Mat::zeros(threshold_out.size(), CV_8UC3);
			for(size_t i = 0; i < contours.size(); i++)
			{
				size_t count = contours[i].size();//��ϵĵ�����Ϊ6
				if( count < 550 )   //ȥ����ԲС��һ��������Բ,�����
					continue;
				RotatedRect box = fitEllipse(contours[i]);//��Բ���
				center.x = cvRound(box.center.x);     
				center.y = cvRound(box.center.y);

				axes.width = cvRound(box.size.width*0.5);
				axes.height = cvRound(box.size.height*0.5);
				box.angle = -box.angle;

				if(abs(axes.width-axes.height)<3)         //��϶��Բ���趨����������ȷ����Ҫ��Բ2������������Բ�ĳ����Ტ���
				{
					drawContours(cimage , contours, (int)i, Scalar::all(255), 1, 8);
					//ellipse(image_roi , box, Scalar(0,0,255), 4, CV_AA);
					//imshow("�����Բ���", image_roi );
					//printf("����λ�ã�x=%d,y=%d\n",axes.width,axes.height);

					midel_radius = (axes.width+axes.height)/2;
					cout<<"Բ�İ뾶Ϊ ��"<<midel_radius<<endl;
					float A_area = PI*axes.width*axes.height;
					float A_length = 2*PI*axes.height+4*(abs(axes.width-axes.height));
					float circular_degree = (4*PI*A_area)/(A_length*A_length);
					cout<<"Բ��Ϊ��"<<circular_degree<<endl;

					if(midel_radius >240 && midel_radius<270)               //��������߶ȵ��ڵĲ�������Ҫ�궨huantujiugai
					{
						small_radius= midel_radius;
						inner_circular_degree = circular_degree;
					}
					else if(midel_radius > 270)
					{
						large_radius= midel_radius;
						outer_circular_degree = circular_degree;
					}

					cout<<"-------------------------------------����������Բ����-----------------------------------------\n"<<endl;
				}
			}
			cout<<"small is :"<<small_radius<<"\n"<<"large is :"<<large_radius<<"\n"<<endl;
			//------------------------------------------------�����⾶-------------------------------------------------------------
			if (small_radius == 0 || large_radius == 0 )
			{
				printf("this is a broken bottle !");
				Damaged_quantity_number++;
				number_data++;
				just1 = 1;
				Serial_write("11",sizeof("aa")-1);
			}
			else
			{
				float INNERstanderd_bottle_r = 17.6,OUTstanderd_bottle_r = 25.6;
				float pixcel_area =  0.04339; //�궨
				INNERCircle_radius =small_radius*pixcel_area*2 - 3.5743;
				OUTCircle_radius =large_radius*pixcel_area*2; //�궨��ֵ
				cout<<"��Բ�İ뾶Ϊ ��"<<inner_circular_degree<<endl;
				cout<<"��Բ�İ뾶Ϊ ��"<<outer_circular_degree<<endl;

			}
			float Damaged_quantity_number1 = Damaged_quantity_number;
			float bottle_sum1 = bottle_sum;
			Damaged_quantity_number_rate = (Damaged_quantity_number1/bottle_sum1)*100;
		} 
		image_grab_done[0] = 0;
		waitKey(1);
	}
	return 0;
}


DWORD WINAPI ThreadFunction2(LPVOID lpParameter)
{	cout << "�߳�2��ʼ���� ! " << endl;
	////�߳�2
	while (1)
	{
		if(image_grab_done[1]==1)
		{
			img = Mat(&Image_Mat[1],true);
			impurity_sum++;
			int height_high = img.rows;
			int width_high = img.cols;
			//cout << "channels: " << img.channels() << endl;
			//imshow("erer",img);
			Rect rect(280,250, 550,550);  //1,2λ������㣬���ĺ�λ�ǿ��
			img = img(rect);
			threshold(img, threshold_output, 200, 255, CV_THRESH_BINARY);
			bitwise_not(threshold_output,threshold_output);    
			int area_acount = 0;
			for (int i = 0;i<threshold_output.rows;i++)
			{
		
				for (int j = 0;j<threshold_output.cols;j++)
					{
					if(threshold_output.at<uchar>(i,j) == 255) 
							{
								area_acount++;
							}
					}
			}
            if (area_acount < 10)  //biaoding de
			{
				printf("There is no impurity at the bottom of the bottle.\n");
			}
			else
			{
			findContours(threshold_output, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_NONE);
			//cout << "num=" << contours.size() << endl;
			double area = 0;
			int i;
			double area_max = contourArea(contours[0]);
			//cout<<"-----------"<<area_max<<endl;
			for (i = 0; i<contours.size(); i++)
			{
				drawContours(img, contours, i, Scalar(0, 0, 255), 4, 8);
				area = contourArea(contours[i]);//�����i�����������
				//cout<<"area"<<area<<endl;
				if (area_max > area)
				{
					area_max = area_max;
				}
				else
				{
					area_max = contourArea(contours[i]);
				}
			}
			cout<<"\n area_max is :"<<area<<endl;

			if (area > 2000)
			{
				printf("There has impurity at the bottom of the bottle.");
				impurity_quantity_number++;
				number_data++;
				just2 = 1;
				Serial_write("00",sizeof("aa")-1);
			}
			if (area < 2000)
			{
				printf("There is no impurity at the bottom of the bottle.\n");	

			}
			}
			image_grab_done[1] = 0;
		}
		float impurity_quantity_number1 = impurity_quantity_number;
		float impurity_sum1 = impurity_sum;
		impurity_quantity_number_rate = (impurity_quantity_number1/impurity_sum1)*100;
	}
	return 0;
}


int _tmain(int argc, _TCHAR* argv[])
{

	Sleep(10*1000);//�ȴ��������

	/* �����ʼ�� */
	PylonInitialize();
	CTlFactory& tlFactory = CTlFactory::GetInstance();
	DeviceInfoList_t devices;
	while(1)
	{
		if ( tlFactory.EnumerateDevices(devices) == 0 )
		{
			cout << "No camera present." << endl;
		}
		else
			break;
	}
	cout << devices.size() <<"Camera connectted!" << endl;

	CInstantCameraArray cameras( devices.size());
	int num_of_camera = devices.size();
	INodeMap *m_pCameraNodeMap[MAX_CAMERA];
	INodeMap *m_pCameraTLNodeMap[MAX_CAMERA];

	cameras.DestroyDevice();

	// Create and attach all Pylon Devices.
	for ( size_t i=0;i<cameras.GetSize();i++)
	{
		cameras[i].Attach( tlFactory.CreateDevice( devices[i]) );

		// Print the model name of the camera.
		cout << "Using device " << cameras[i].GetDeviceInfo().GetModelName() << endl;
	}

	//���ø���������¼���������,���������Ҫ��EventPrinter.h�ļ������ಢ������Ӧ���޸�
	cameras[0].RegisterConfiguration( new CEventPrinter_1, RegistrationMode_Append, Cleanup_None);
	cameras[0].RegisterImageEventHandler( new CEventPrinter_1, RegistrationMode_Append, Cleanup_None);

	cameras[1].RegisterConfiguration( new CEventPrinter_2, RegistrationMode_Append, Cleanup_None);
	cameras[1].RegisterImageEventHandler( new CEventPrinter_2, RegistrationMode_Append, Cleanup_None);

	cameras.Open();
	for(size_t i=0;i<cameras.GetSize();i++)
	{
		m_pCameraNodeMap[i] = &cameras[i].GetNodeMap();
		m_pCameraTLNodeMap[i] = &cameras[i].GetTLNodeMap();
		//��������ɼ�ͼ���С
		// Get the integer nodes describing the AOI.
		CIntegerPtr offsetX( m_pCameraNodeMap[i]->GetNode( "OffsetX"));
		CIntegerPtr offsetY( m_pCameraNodeMap[i]->GetNode( "OffsetY"));
		CIntegerPtr width( m_pCameraNodeMap[i]->GetNode( "Width"));
		CIntegerPtr height( m_pCameraNodeMap[i]->GetNode( "Height"));
		// On some cameras the offsets are read-only,
		// so we check whether we can write a value. Otherwise, we would get an exception.
		// GenApi has some convenience predicates to check this easily.
		width->SetValue( m_WidthControl );
		height->SetValue( m_HeightControl );
		if ( IsWritable( offsetX))
		{
			offsetX->SetValue( m_OffsetXControl );
		}
		if ( IsWritable( offsetY))
		{
			offsetY->SetValue( m_OffsetYControl );
		}
		// Some properties have restrictions. Use GetInc/GetMin/GetMax to make sure you set a valid value.
		//int64_t newWidth = 202;
		//newWidth = Adjust(newWidth, width->GetMin(), width->GetMax(), width->GetInc());

		//int64_t newHeight = 101;
		//newHeight = Adjust(newHeight, height->GetMin(), height->GetMax(), height->GetInc());

		//��������ع�ʱ��
		CEnumerationPtr exposureAuto= m_pCameraNodeMap[i]->GetNode( "ExposureAuto");
		if ( IsWritable( exposureAuto))
		{
			exposureAuto->FromString("Off");
		}

		CIntegerPtr ExposureTimeRaw(m_pCameraNodeMap[i]->GetNode( "ExposureTimeRaw"));
		ExposureTimeRaw->SetValue(m_ExposureTimeControl);

		//�������Ϊ�ⲿ������ͬʱ���ƹ�Դ����
		CEnumerationPtr triggerMode = m_pCameraNodeMap[i]->GetNode( "TriggerMode" );
		if ( IsWritable( triggerMode ))
		{
			triggerMode->FromString("On");
		}

		CEnumerationPtr triggerActivation = m_pCameraNodeMap[i]->GetNode( "TriggerActivation" );
		if ( IsWritable( triggerActivation ))
		{
			triggerActivation->FromString("RisingEdge");
		}

		CFloatPtr triggerDelayAbs(m_pCameraNodeMap[i]->GetNode( "TriggerDelayAbs"));
		float newTriggerDelayAbs = 0.0;
		triggerDelayAbs->SetValue(newTriggerDelayAbs);

		CEnumerationPtr lineSelector = m_pCameraNodeMap[i]->GetNode( "LineSelector" );
		if ( IsWritable( lineSelector ))
		{
			lineSelector->FromString("Out1");
		}

		CEnumerationPtr lineMode = m_pCameraNodeMap[i]->GetNode( "LineMode" );
		if ( IsWritable( lineMode ))
		{
			lineMode->FromString("Output");
		}

		CEnumerationPtr lineSource = m_pCameraNodeMap[i]->GetNode( "LineSource" );
		if ( IsWritable( lineSource ))
		{
			lineSource->FromString("ExposureActive");
		}

		//�������������ʱ��
		CIntegerPtr heartbeatTimeout(m_pCameraTLNodeMap[i]->GetNode( "HeartbeatTimeout" ));
		heartbeatTimeout->SetValue(m_HeartbeatTimeoutControl);

		//��������ɼ�

		cameras[i].StartGrabbing(GrabStrategy_LatestImageOnly, GrabLoop_ProvidedByInstantCamera);

		image_grab_done[i] = 0;
	}
	//---------------------------------------------------------------------------------------------------

	HANDLE handle1, handle2;
	handle1 = CreateThread(NULL, 0, ThreadFunction1, NULL, 0, NULL);
	handle2 = CreateThread(NULL, 0, ThreadFunction2, NULL, 0, NULL);
	if (NULL == handle1)
	{
		cout << "�����߳�1ʧ�� !" << endl;
		return -1;
	}
	if (NULL == handle2)
	{
		cout << "�����߳�2ʧ�� !" << endl;
		return -1;
	}

	CloseHandle(handle1);
	CloseHandle(handle2);//������֮��ر��߳�
	cout << "���߳����� !" << endl;
	
	Mat input_figure1 =Mat::zeros(318, 318, CV_8UC3);
	Mat input_figure3 =Mat::ones(238, 318, CV_8UC3);
	Mat putu = imread("putu.png");

	
	while(1)
	{	
		Mat dst = imread("background.png");
		if(!image_roi.data == 0)
		{
		Mat image_roi2;
		cvtColor(image_roi,image_roi2, CV_GRAY2BGR);
		//cout<<image_roi2.channels()<<endl;
		resize(image_roi2,image_roi2,Size(318,318));
		image_roi2.copyTo(input_figure1);
		}

		if(!img.data == 0)
		{
		Mat img2;
		cvtColor(img,img2, CV_GRAY2BGR);
		resize(img2,img2,Size(318,238));
		img2.copyTo(input_figure3);
		}

		input_figure1.copyTo (dst(Rect(83,284,input_figure1.cols,input_figure1.rows)));
		input_figure3.copyTo (dst(Rect(83,635,input_figure3.cols,input_figure3.rows)));
		
		if(!image_roi.data == 0 || !img.data == 0)
		{
		char buf[256];
			sprintf_s(buf,256,"%d",bottle_sum);
			putText(dst,buf,Point(546,376),CV_FONT_HERSHEY_PLAIN ,1,Scalar(0,0,0),2,8);//ƿ������
			sprintf_s(buf,256,"%d",impurity_sum);
			putText(dst,buf,Point(546,723),CV_FONT_HERSHEY_PLAIN ,1,Scalar(0,0,0),2,8);//��������

			sprintf_s(buf,256,"%d",Damaged_quantity_number);
			putText(dst,buf,Point(779,376),CV_FONT_HERSHEY_PLAIN ,1,Scalar(0,0,0),2,8);//������
			sprintf_s(buf,256,"%d",impurity_quantity_number);
			putText(dst,buf,Point(779,723),CV_FONT_HERSHEY_PLAIN ,1,Scalar(0,0,0),2,8);//������

			sprintf_s(buf,256,"%.2f",INNERCircle_radius);
			putText(dst,buf,Point(779,443),CV_FONT_HERSHEY_PLAIN ,1,Scalar(0,0,0),2,8);//�ڲ��뾶
			sprintf_s(buf,256,"%.2f",OUTCircle_radius);
			putText(dst,buf,Point(546,443),CV_FONT_HERSHEY_PLAIN ,1,Scalar(0,0,0),2,8);//�ⲿ�뾶

			sprintf_s(buf,256,"%f",inner_circular_degree);
			putText(dst,buf,Point(779,510),CV_FONT_HERSHEY_PLAIN ,1,Scalar(0,0,0),2,8);  //Բ��
			sprintf_s(buf,256,"%f",outer_circular_degree);
			putText(dst,buf,Point(546,510),CV_FONT_HERSHEY_PLAIN ,1,Scalar(0,0,0),2,8);  //Բ��
			
			sprintf_s(buf,256,"%0.2f%%",Damaged_quantity_number_rate);
			putText(dst,buf,Point(779,579),CV_FONT_HERSHEY_PLAIN ,1,Scalar(0,0,0),2,8);  //������

			sprintf_s(buf,256,"%0.2f%%",impurity_quantity_number_rate);
			putText(dst,buf,Point(779,845),CV_FONT_HERSHEY_PLAIN,1,Scalar(0,0,0),2,8);  //������	

			if (just1 == 1)
			{
				putTextZH(dst, "ƿ������", Point(546,560), Scalar(0, 0, 0), 18, "����");
			}
			if(just1 == 0)
			{
				putTextZH(dst, "ƿ��������", Point(546,560), Scalar(0, 0, 0), 18, "����");
			}
			if (just2 == 1)
			{
				putTextZH(dst, "ƿ��������", Point(546,828), Scalar(0, 0, 0), 18, "����");
			}
			if(just2 == 0)
			{
				putTextZH(dst, "ƿ��������", Point(546,828), Scalar(0, 0, 0), 18, "����");
			}

//------------------------------------------�б�----------------------------------------------------

		if (number_data ==1)
			{
			if (just1 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54), Scalar(0, 0, 0), 18, "����"); //+54
				just1 = 0;
			}
				if (just2 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54), Scalar(0, 0, 0), 18, "����");//+54
				just2 = 0;
			}
			}

		if (number_data ==2)
			{
			if (just1 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*2), Scalar(0, 0, 0), 18, "����");
				just1 = 0;
			}
				if (just2 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*2), Scalar(0, 0, 0), 18, "����");
				just2 = 0;
			}
			}

		if (number_data ==3)
			{
			if (just1 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*3), Scalar(0, 0, 0), 18, "����");
				just1 = 0;
			}
				if (just2 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*3), Scalar(0, 0, 0), 18, "����");
				just2 = 0;
			}
			}

		if (number_data ==4)
			{
			if (just1 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*4), Scalar(0, 0, 0), 18, "����");
				just1 = 0;
			}
				if (just2 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*4), Scalar(0, 0, 0), 18, "����");
				just2 = 0;
			}
			}

		if (number_data ==5)
			{
			if (just1 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*5), Scalar(0, 0, 0), 18, "����");
				just1 = 0;
			}
				if (just2 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*5), Scalar(0, 0, 0), 18, "����");
				just2 = 0;
			}
			}

		if (number_data ==6)
			{
			if (just1 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*6), Scalar(0, 0, 0), 18, "����");
				just1 = 0;
			}
				if (just2 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*6), Scalar(0, 0, 0), 18, "����");
				just2 = 0;
			}
			}

		if (number_data ==7)
			{
			if (just1 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*7), Scalar(0, 0, 0), 18, "����");
				just1 = 0;
			}
				if (just2 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*7), Scalar(0, 0, 0), 18, "����");
				just2 = 0;
			}
			}

		if (number_data ==8)
			{
			if (just1 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*8), Scalar(0, 0, 0), 18, "����");
				just1 = 0;
			}
				if (just2 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*8), Scalar(0, 0, 0), 18, "����");
				just2 = 0;
			}
			}

		if (number_data ==9)
			{
			if (just1 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*9), Scalar(0, 0, 0), 18, "����");
				just1 = 0;
			}
				if (just2 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*9), Scalar(0, 0, 0), 18, "����");
				just2 = 0;
			}
			}

		if (number_data ==10)
			{
			if (just1 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*10), Scalar(0, 0, 0), 18, "����");
				just1 = 0;
			}
				if (just2 == 1)
			{
				putTextZH(putu, "����", Point(84,286+54*10), Scalar(0, 0, 0), 18, "����");
				just2 = 0;
			}
			}
		if (number_data ==11)
		{
			number_data	 = 0;
			putu = imread("putu.png");
		}
			putu.copyTo(dst(Rect(929,0,putu.cols,putu.rows)));
		}		

//-----------------------------------------------------------------------------------------------------		

		//resize(dst,dst,Size(800,600));
		namedWindow("FullScreen", CV_WINDOW_NORMAL);
		setWindowProperty("FullScreen", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);//����������ȫ��	
		imshow("FullScreen", dst);
		
		//Time = (double)cvGetTickCount() - Time ;
		//printf( "run time = %gms\n", Time /(cvGetTickFrequency()*1000) );
		
		waitKey(3);
	}
	destroyAllWindows();
	//�˳�ʱ����
	PylonTerminate();
	return 0;
}

