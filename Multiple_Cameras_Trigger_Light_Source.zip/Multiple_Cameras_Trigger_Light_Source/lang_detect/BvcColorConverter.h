//-----------------------------------------------------------------------------
//  (c) 2002 by Basler Vision Technologies
//  Section:  Vision Components
//  Project:  BVC
//  $Header: BvcColorConverter.h, 6, 24.10.2003 16:56:13, Happe, A.$
//-----------------------------------------------------------------------------
/**
  \file     BvcColorConverter.h
 *
  \brief   <type brief description here>
 *
 * <type long description here>
 */
//-----------------------------------------------------------------------------

#if !defined(AFX_BVCCOLORCONVERTER_H__FE22DC3C_A5BF_4487_A323_84DE8CC72022__INCLUDED_)
#define AFX_BVCCOLORCONVERTER_H__FE22DC3C_A5BF_4487_A323_84DE8CC72022__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <assert.h>

#if defined( USE_MFC )
#include <afxwin.h>         // MFC core and standard components
#else
#include <windows.h>
#endif

#if defined( USE_WTL )
#include <atlapp.h>
#include <atlmisc.h>        // WTL's CSIZE,...
#endif  

#if _MSC_VER >= 1300
#include <atltypes.h>  // CSize, CPoint, ...
#endif


namespace Bvc
{

  //! The length of the look-up tables
  enum{ LUT_LENGTH = 256 };

  class CDibPtr;

  //! Converter for various color formats in RGB8
  class CColorConverter
  {
  public:
    //! Indicates the Bayer pattern of the first row of an image.
    enum  PatternOrigin_t
    {
      poGB = 1, //!< Bayer Image starts with a GBGB row
      poGR,     //!< Bayer Image starts with a GRGR row
      poB,      //!< Bayer Image starts with a BGBG row
      poR       //!< Bayer Image starts with a RGRG row
    };

  //! Converts a Bayer8 to a RGB8 image (works on CDibPtr) 
    static void ConvertMono8ToRGB(CDibPtr &ptrDest, const CDibPtr &ptrSource, PatternOrigin_t PatternOrigin);

    //! Converts a Bayer8 to a RGB8 image with LUTs (works on CDibPtr) 
    static void ConvertMono8ToRGB(CDibPtr &ptrDest, const CDibPtr &ptrSource, PatternOrigin_t PatternOrigin, 
       const BYTE pLutR[LUT_LENGTH],  const BYTE pLutG[LUT_LENGTH],  const BYTE pLutB[LUT_LENGTH]);

    //! Converts a 422YUV8 to a RGB8 image (the destination image is a CDibPtr)
    static void ConvertYUV422ToRGB(CDibPtr &ptrDest, const BYTE* pSource);

    //! Converts a 422YUV8 to a RGB8 image (works on raw pointers)
    static void ConvertYUV422ToRGB(BYTE* pDest, const BYTE* pSource,  const CSize& Size, unsigned int lineoffset = 0);

    //! Converts a Bayer8 to a RGB8 image with LUTs (works on raw pointers)
    static void ConvertMono8ToRGB(BYTE* pDest,  const BYTE* pSource,  const CSize& Size, PatternOrigin_t PatternOrigin, 
       const BYTE pLutR[LUT_LENGTH],  const BYTE pLutG[LUT_LENGTH],  const BYTE pLutB[LUT_LENGTH]);

    //! Converts a Bayer8 to a RGB8 image with LUTs (works on raw pointers) Different strides in source and destination buffer are considered. 
    static void ConvertMono8ToRGB(BYTE* pDest,  const BYTE* pSource,  const CSize& Size, PatternOrigin_t PatternOrigin, 
                                  int strideDest, unsigned int strideSource);

    //! Converts a Bayer8 to a RGB8 image with LUTs (works on raw pointers). Different strides in source and destination buffer are considered. 
    static void ConvertMono8ToRGB(BYTE* pDest, const BYTE* pSource, const CSize& Size, PatternOrigin_t PatternOrign,
      int strideDest, unsigned int strideSource,
      const BYTE pLutR[LUT_LENGTH],  const BYTE pLutG[LUT_LENGTH],  const BYTE pLutB[LUT_LENGTH]);  



  protected:

    class GBLineConverter 
    {
    public:
      inline static void Convert(const BYTE*& pRaw, const BYTE* pRawEnd, 
        const BYTE pLutR[LUT_LENGTH], const BYTE pLutG[LUT_LENGTH], const BYTE pLutB[LUT_LENGTH],
        const unsigned int strideSource, RGBTRIPLE*& pRGB);
    };

    class RGLineConverter
    {
    public:
      inline static void Convert(const BYTE*& pRaw, const BYTE* pRawEnd, 
        const BYTE pLutR[LUT_LENGTH], const BYTE pLutG[LUT_LENGTH], const BYTE pLutB[LUT_LENGTH],
        const unsigned int strideSource, RGBTRIPLE*& pRGB);
    };

    class BGLineConverter
    {
    public:
      inline static void Convert(const BYTE*& pRaw, const BYTE* pRawEnd, 
        const BYTE pLutR[LUT_LENGTH], const BYTE pLutG[LUT_LENGTH], const BYTE pLutB[LUT_LENGTH],
        const unsigned int strideSource, RGBTRIPLE*& pRGB);
    };

    class GRLineConverter
    {
    public:
      inline static void Convert(const BYTE*& pRaw, const BYTE* pRawEnd, 
        const BYTE pLutR[LUT_LENGTH], const BYTE pLutG[LUT_LENGTH], const BYTE pLutB[LUT_LENGTH],
        const unsigned int strideSource, RGBTRIPLE*& pRGB);
    };


    //! Converts every second line of an Bayer Image into RGB.
    template<class LineConverter> 
      static void ConvertMono8ToRGB(RGBTRIPLE* pDest,  const BYTE* pSource,  const CSize& Size, unsigned int lineoffset,
      int strideDest, unsigned int strideSource,
      const BYTE pLutR[LUT_LENGTH],  const BYTE pLutG[LUT_LENGTH],  const BYTE pLutB[LUT_LENGTH]);




  };

  

} // namespace Bvc
#endif // !defined(AFX_BVCCOLORCONVERTER_H__FE22DC3C_A5BF_4487_A323_84DE8CC72022__INCLUDED_)
