#include "macro_define.h"
#include "cv.h"
#include "cxcore.h"
#include "highgui.h"
#include "imgproc\imgproc.hpp"

using namespace cv;

int m_max_cameras = MAX_CAMERA;

int m_WidthControl = 1600;
int m_HeightControl = 1200;
int m_OffsetXControl = 0;
int m_OffsetYControl = 0;
int64_t m_ExposureTimeControl = 800;
int64_t m_HeartbeatTimeoutControl = 1000;//1000ms 

CvMat Image_Mat[MAX_CAMERA]; //���ڽ�ͼ�񴫵ݸ��������������
int image_grab_done[MAX_CAMERA];
