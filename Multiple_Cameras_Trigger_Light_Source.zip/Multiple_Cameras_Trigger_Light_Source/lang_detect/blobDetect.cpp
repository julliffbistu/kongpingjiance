#include "StdAfx.h"
#include"blobDetect.h"
#include "varable_decaration.h"

/******************************************************************************/
blobDetect::blobDetect()
{
	SearchDirection[0][0] = 0;
	SearchDirection[0][1] = 1;
	SearchDirection[1][0] = 1;
	SearchDirection[1][1] = 1;
	SearchDirection[2][0] = 1;
	SearchDirection[2][1] = 0;
	SearchDirection[3][0] = 1;
	SearchDirection[3][1] = -1;
	SearchDirection[4][0] = 0;
	SearchDirection[4][1] = -1;
	SearchDirection[5][0] = -1;
	SearchDirection[5][1] = -1;
	SearchDirection[6][0] = -1;
	SearchDirection[6][1] = 0;
	SearchDirection[7][0] = -1;
	SearchDirection[7][1] = 1;
	DRow = Detect_Kuan_Region_Y2-Detect_Kuan_Region_Y1+1;
	DCol = Detect_Kuan_Region_X2-Detect_Kuan_Region_X1+1;
	Label = (char *)malloc(DRow*DCol);
	memset(Label,0,DRow*DCol);
	Region_Count = 0;
}
/******************************************************************************/
blobDetect::~blobDetect()
{
	free(Label);
}
/****************************************************************************/
int blobDetect::getNumOfBlobs()
{
	int num;
	num = Region_Count;
	return num;
}
/******************************************************************************/
regionprops* blobDetect::getBlobN(int givenNo)
{
   regionprops *newBlob;
   if(givenNo<Region_Count)
   {
	   newBlob = (regionprops *)malloc(sizeof(regionprops));
	   *newBlob = Region_Stats[givenNo];
	   return newBlob;
   }
   else
	   return NULL;
}
/******************************************************************************/
void blobDetect::tracer(IplImage *image, int *x, int *y, int *tracingdirection)
{
	int i,x0,y0;
	int row = image->height;
	int col = image->width;
	for(i=0;i<7;i++)
	{
		x0 = *x + SearchDirection[*tracingdirection][0];
		y0 = *y + SearchDirection[*tracingdirection][1];

		if(CV_IMAGE_ELEM(image,uchar,x0,y0) == 0)
		{
			*(Label+x0*col+y0) = -1;
			*tracingdirection = (*tracingdirection + 1)%8;
		}
		else
		{
			*x = x0;
			*y = y0;
			break;
		}
	}
}
/******************************************************************************/
void blobDetect::contour_tracing(IplImage *image, int x, int y, int labelindex, int tracingdirection)
{
	char tracingstopflag = 0,SearchAgain = 1;
	int fx,fy,sx=x,sy=y;
	int row = image->height;
	int col = image->width;
	tracer(image,&x,&y,&tracingdirection);
	if(x!=sx||y!=sy)
	{
		fx = x;
		fy = y;
		while(SearchAgain)
		{
			tracingdirection = (tracingdirection + 6)%8;
			if(tracingstopflag==0&&labelindex<=MAX_REGION)
			{
				if(Region_Stats[labelindex-1].maxr<x)
					Region_Stats[labelindex-1].maxr = x;
				if(Region_Stats[labelindex-1].minr>x)
					Region_Stats[labelindex-1].minr = x;
				if(Region_Stats[labelindex-1].maxc<y)
					Region_Stats[labelindex-1].maxc = y;
				if(Region_Stats[labelindex-1].minc>y)
					Region_Stats[labelindex-1].minc = y;
				Region_Stats[labelindex-1].region_area += 1;
				Region_Stats[labelindex-1].region_sum_x += x;
				Region_Stats[labelindex-1].region_sum_y += y;
			}
			*(Label+x*col+y) = labelindex;
			tracer(image,&x,&y,&tracingdirection);
			if(x==sx&&y==sy)
			{
				tracingstopflag = 1;
			}
			else if(tracingstopflag)
			{
				if(x==fx&&y==fy)
				{
					SearchAgain = 0;
				}
				else
				{
					tracingstopflag = 0;
				}
			}
		}
	}
}
/******************************************************************************/
void blobDetect::connected_labeling(IplImage *image)//(IplImage *image, IplImage *diff, IplImage *orig)
{
	int i;
	int x,y,tracingdirection,ConnectedComponentsCount = 0,labelindex = 0;
	int row = image->height;
	int col = image->width;
	Region_Count = 0;
	memset(Label,0,row*col);
	for(x=1;x<row-1;x++)   //x��ʾ�У�y��ʾ��
	{
		for(y=1,labelindex=0;y<col-1;y++)
		{
			if(CV_IMAGE_ELEM(image,uchar,x,y))//(Y_original[x][y] == 1)  //black pixel
			{
				if(labelindex != 0) //use pre-pixel label
				{
					*(Label+x*col+y) = labelindex;
					if(labelindex<=MAX_REGION)
					{
						Region_Stats[labelindex-1].region_area += 1;
						Region_Stats[labelindex-1].region_sum_x += x;
						Region_Stats[labelindex-1].region_sum_y += y;
					}
				}
				else
				{
					labelindex = *(Label+x*col+y);
					if(labelindex == 0)
					{
						labelindex = ++ConnectedComponentsCount;
						tracingdirection = 0;
						if(labelindex<=MAX_REGION)
						{
							Region_Stats[labelindex-1].maxr = 0;
							Region_Stats[labelindex-1].minr = row-1;
							Region_Stats[labelindex-1].maxc = 0;
							Region_Stats[labelindex-1].minc = col-1;
							Region_Stats[labelindex-1].region_area = 0;
							Region_Stats[labelindex-1].region_sum_x = 0;
							Region_Stats[labelindex-1].region_sum_y = 0;
							if(Region_Stats[labelindex-1].maxr<x)
								Region_Stats[labelindex-1].maxr = x;
							if(Region_Stats[labelindex-1].minr>x)
								Region_Stats[labelindex-1].minr = x;
							if(Region_Stats[labelindex-1].maxc<y)
								Region_Stats[labelindex-1].maxc = y;
							if(Region_Stats[labelindex-1].minc>y)
								Region_Stats[labelindex-1].minc = y;
							Region_Stats[labelindex-1].region_area += 1;
							Region_Stats[labelindex-1].region_sum_x += x;
							Region_Stats[labelindex-1].region_sum_y += y;
						}
						contour_tracing(image,x,y,labelindex,tracingdirection);//(image,diff,orig,x,y,labelindex,tracingdirection); //external contour
						*(Label+x*col+y) = labelindex;
						if(labelindex<=MAX_REGION)
						{
							Region_Stats[labelindex-1].rectangel_box[0][0] = Region_Stats[labelindex-1].minr;
							Region_Stats[labelindex-1].rectangel_box[0][1] = Region_Stats[labelindex-1].minc;
							Region_Stats[labelindex-1].rectangel_box[1][0] = Region_Stats[labelindex-1].maxr;
							Region_Stats[labelindex-1].rectangel_box[1][1] = Region_Stats[labelindex-1].maxc;
							Region_Stats[labelindex-1].region_centor[0] = (Region_Stats[labelindex-1].minr+Region_Stats[labelindex-1].maxr)/2.0;
							Region_Stats[labelindex-1].region_centor[1] = (Region_Stats[labelindex-1].minc+Region_Stats[labelindex-1].maxc)/2.0;
							Region_Count += 1;
						}
						else
							break;
					}
				}
			}
			else if(labelindex != 0) //white pixel & pre-pixel has been labeled
			{
				if(*(Label+x*col+y) == 0)
				{
					tracingdirection = 1;
					contour_tracing(image,x,y-1,labelindex,tracingdirection);//(image,diff,orig,x,y-1,labelindex,tracingdirection); //internal contour
				}
				labelindex = 0;
			}
		}
		if(labelindex>MAX_REGION)
			break;
	}

	//������������ĻҶ�����
	/*for(i=0;i<Region_Count;i++)
	{
		Region_Stats[i].region_gray_centor[0] = Region_Stats[i].region_sum_x*1.0/Region_Stats[i].region_area;
		Region_Stats[i].region_gray_centor[1] = Region_Stats[i].region_sum_y*1.0/Region_Stats[i].region_area;
	}*/
}
