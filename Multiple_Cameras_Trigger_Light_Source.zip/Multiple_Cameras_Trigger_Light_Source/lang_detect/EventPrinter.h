// Contains an Image Event Handler that prints a message for each event method call.

#ifndef INCLUDED_IMAGEEVENTPRINTER_H_7884943
#define INCLUDED_IMAGEEVENTPRINTER_H_7884943

#include <pylon/ImageEventHandler.h>
#include <pylon/ConfigurationEventHandler.h>
#include <pylon/GrabResultPtr.h>
#include <iostream>
#include "varable_decaration.h"

#include "cv.h"
#include "cxcore.h"
#include "highgui.h"
#include "imgproc\imgproc.hpp"

using namespace std;
using namespace cv;

namespace Pylon
{
    class CInstantCamera;

    class CEventPrinter_1 : public CImageEventHandler  // For receiving grabbed images.
		, public CConfigurationEventHandler  // For getting notified about device removal.
    {
    public:
		// Instant Camera Image Event.
		// This is where we are going the receive the grabbed images.
		// This method is called from the Instant Camera grab loop thread.
        virtual void OnImageGrabbed( CInstantCamera& camera, const CGrabResultPtr& ptrGrabResult)
        {
			if (ptrGrabResult->GrabSucceeded())
			{
				Image_Mat[0] = cvMat(ptrGrabResult->GetHeight(),ptrGrabResult->GetWidth(),CV_8UC1,(unsigned char*)ptrGrabResult->GetBuffer());
				image_grab_done[0] = 1;
			}
        }

		// Instant Camera Configuration Event.
		// This method is called from the Instant Camera grab loop thread.
		virtual void OnGrabError( CInstantCamera& camera, const char* errorMessage)
		{
			// Do not handle errors caused by device removal.
			if ( !camera.IsCameraDeviceRemoved())
			{
				cout << "An error occurred during grabbing = " << errorMessage << endl;

				// �������μ��,�����¿�ʼ�ɼ�
				camera.StopGrabbing();
				if(camera.IsPylonDeviceAttached())
				{
					camera.StartGrabbing(GrabStrategy_LatestImageOnly, GrabLoop_ProvidedByInstantCamera);
				}
			}
		}

		// Instant Camera Configuration Event.
		// This method is called from additional Instant Camera thread.
		virtual void OnCameraDeviceRemoved( CInstantCamera& camera)
		{
			// Stop the grab; close the pylon device; destroy the pylon device.
			// DestroyDevice does not throw C++ exceptions.
			camera.DestroyDevice();
			cout << "The camera device has been removed." << endl;
			// ֪ͨ���������������,���м���
		}
    };

	class CEventPrinter_2 : public CImageEventHandler  // For receiving grabbed images.
		, public CConfigurationEventHandler  // For getting notified about device removal.
	{
	public:
		// Instant Camera Image Event.
		// This is where we are going the receive the grabbed images.
		// This method is called from the Instant Camera grab loop thread.
		virtual void OnImageGrabbed( CInstantCamera& camera, const CGrabResultPtr& ptrGrabResult)
		{
			if (ptrGrabResult->GrabSucceeded())
			{
				Image_Mat[1] = cvMat(ptrGrabResult->GetHeight(),ptrGrabResult->GetWidth(),CV_8UC1,(unsigned char*)ptrGrabResult->GetBuffer());
				image_grab_done[1] = 1;
			}
		}

		// Instant Camera Configuration Event.
		// This method is called from the Instant Camera grab loop thread.
		virtual void OnGrabError( CInstantCamera& camera, const char* errorMessage)
		{
			// Do not handle errors caused by device removal.
			if ( !camera.IsCameraDeviceRemoved())
			{
				cout << "An error occurred during grabbing = " << errorMessage << endl;

				// �������μ��,�����¿�ʼ�ɼ�
				camera.StopGrabbing();
				if(camera.IsPylonDeviceAttached())
				{
					camera.StartGrabbing(GrabStrategy_LatestImageOnly, GrabLoop_ProvidedByInstantCamera);
				}
			}
		}

		// Instant Camera Configuration Event.
		// This method is called from additional Instant Camera thread.
		virtual void OnCameraDeviceRemoved( CInstantCamera& camera)
		{
			// Stop the grab; close the pylon device; destroy the pylon device.
			// DestroyDevice does not throw C++ exceptions.
			camera.DestroyDevice();
			cout << "The camera device has been removed." << endl;
			// ֪ͨ���������������,���м���
		}
	};
}

#endif /* INCLUDED_IMAGEEVENTPRINTER_H_7884943 */
