#pragma once

// Include files to use the PYLON API
#include <pylon/PylonIncludes.h>
#include <pylon/ImageEventHandler.h>
#include "ConfigurationEventPrinter.h"
#include "ImageEventPrinter.h"
//#include "ImageEventPrinterr.h"
#include "CameraConfiguration.h"
#include <float.h>
#include <stdlib.h>
#include <stdio.h>
#include <afxtempl.h>
#include <time.h>
#include "blobDetect.h"

#include "cv.h"
#include "cxcore.h"
#include "highgui.h"
#include "imgproc\imgproc.hpp"

using namespace std;
using namespace cv;
using namespace Pylon;
using namespace GenApi;

class ViewPylon : public CImageEventHandler             // For receiving grabbed images.
    , public CConfigurationEventHandler     // For getting notified about device removal.
{
public:
	ViewPylon(void);

protected:
	// Instant Camera Image Event.
    // This is where we are going the receive the grabbed images.
    // This method is called from the Instant Camera grab loop thread.
    virtual void OnImageGrabbed( CInstantCamera& camera, const CGrabResultPtr& ptrGrabResult);

    // Instant Camera Configuration Event.
    // This method is called from the Instant Camera grab loop thread.
    virtual void OnGrabError( CInstantCamera& camera, const char* errorMessage);

    // Instant Camera Configuration Event.
    // This method is called from additional Instant Camera thread.
    virtual void OnCameraDeviceRemoved( CInstantCamera& camera);
};

